function mascaraCpf(campo, evento){
	cpf=campo.value;
	posicao=cpf.length;
	tecla=evento.keyCode;
	if((tecla!=8) && (tecla!=46)){
		if((posicao==3) || (posicao==7)){
			campo.value=cpf+".";
		}else{
			if(posicao==11){
				campo.value=cpf+"-";
			}
		}
	}
}
function verificaCaracter(campo, evento){
    var tecla=evento.keyCode;
    if((tecla!=8) && (tecla!=37) && (tecla!=38) && (tecla!=39) && (tecla!=40) && (tecla!=46)){
        if(!(tecla>=48 && tecla<=57) && !(tecla>=96 && tecla<=105)){
            antigoValor=campo.value;
			novoValor=antigoValor.replace(/\D/g, "");
            campo.value=novoValor;   
        }
    }
} 
function verificaCpf(){
    var digitoUm=0;
	var digitoDois=0;
	var calculoUm=0;
	var calculoDois=0;
	var valido=null;
    var divCpf = document.getElementById('divCpf');
	var msg = document.getElementById('validacaoCpf');
    var campoCpf = document.getElementById('cpf');
    
	cpf=campoCpf.value;
	if(cpf==""){
		divCpf.style.color="#FF0000";
		msg.textContent="Campo obrigat�rio";
		campoCpf.className="cpfFocusInvalido";
	}else{
		if(cpf.length==11){
			if(cpf==00000000000 || cpf==11111111111 || cpf==22222222222 || cpf==33333333333 || cpf==44444444444 || cpf==55555555555 || cpf==66666666666 || cpf==77777777777 || cpf==88888888888 || cpf==99999999999){
				valido=false;
			}else{
				for(i=0, x=10; i<=8; i++, x--){
					calculoUm+=cpf[i]*x;
				}
				for(i=0, x=11; i<=9; i++, x--){
					calculoDois+=cpf[i]*x;
				}
				if(calculoUm%11 < 2){
					digitoUm=0;
				}else{
					digitoUm=11-(calculoUm%11);
				}
				if(calculoDois%11 < 2){
					digitoDois=0;
				}else{
					digitoDois=11-(calculoDois%11);
				}
				if(digitoUm == cpf[9] && digitoDois == cpf[10]){
					valido=true;
				}else{
					valido=false;   
				}   
			}    
		}else{
			valido=false;
		}
		if(valido==true){
			divCpf.style.color="#228B22";
			msg.textContent="CPF v�lido";
			campoCpf.className="cpfFocusValido";
		}else{
			divCpf.style.color="#FF0000";
			msg.textContent="CPF inv�lido";
			campoCpf.className="cpfFocusInvalido";
		}
	}
}